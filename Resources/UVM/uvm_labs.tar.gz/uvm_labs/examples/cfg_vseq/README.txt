UVM example of configuring a virtual sequence

The protocol is a simplified AHB-Lite and does not represent actual hardware

This expands the code in the Mentor SystemVerilog UVM course, module 9

Includes scripts to compile and run on Unix, Windows, and in Questa
