UVM example of a scoreboard with a separate evaluator and predictor.

This expands the code in the Mentor UVM Basics course, module 7

Includes scripts to compile and run on Unix, Windows, and in Questa

