UVM example of a sequence sending a request, and the driver returning
a shared response object. See the code in ahb_write_sequence.svh and
ahb_driver.svh


No virtual sequences, no test base class

The protocol is a simplified AHB-Lite and does not represent actual hardware

This expands the code in the Mentor SystemVerilog UVM course, module 9

Includes scripts to compile and run on Unix, Windows, and in Questa
